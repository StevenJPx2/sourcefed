export { default, Sourcefed } from "./adapters/opencode/index.js";
