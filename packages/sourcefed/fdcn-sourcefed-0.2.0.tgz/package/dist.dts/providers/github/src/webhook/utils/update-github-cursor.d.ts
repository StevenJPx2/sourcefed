import type { MonitorEvent } from "@fdcn/sourcefed/core";
import type { GithubCursor } from "../../types";
export declare function updateGithubCursor(event: MonitorEvent, cursorRaw: unknown): GithubCursor;
