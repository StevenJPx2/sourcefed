import type { GithubCursor, GithubEvent } from "../../types";
export declare function appendGithubCiEvent(repo: string, prNumber: number, cursor: GithubCursor, events: GithubEvent[], rollup: any[]): Promise<void>;
