export declare function githubPullRequestNumber(payload: any, eventName: string): number | undefined;
