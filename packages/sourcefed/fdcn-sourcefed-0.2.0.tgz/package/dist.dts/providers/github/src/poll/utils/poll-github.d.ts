import type { GithubCursor, GithubEvent } from "../../types";
export declare function pollGithub(repo: string, prNumber: number, cursorRaw: unknown): Promise<{
    events: GithubEvent[];
    cursor: GithubCursor;
    terminal: boolean;
}>;
