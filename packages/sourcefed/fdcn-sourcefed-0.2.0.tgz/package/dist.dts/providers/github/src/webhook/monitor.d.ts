import { WebhookMonitor } from "@fdcn/sourcefed/core";
import type { GithubSourceRecord } from "../types";
export declare const githubWebhookMonitor: WebhookMonitor<GithubSourceRecord>;
