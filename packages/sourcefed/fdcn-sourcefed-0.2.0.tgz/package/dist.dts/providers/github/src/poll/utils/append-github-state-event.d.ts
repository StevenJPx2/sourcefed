import type { GithubCursor, GithubEvent } from "../../types";
export declare function appendGithubStateEvent(repo: string, prNumber: number, cursor: GithubCursor, events: GithubEvent[], prState: string): boolean;
