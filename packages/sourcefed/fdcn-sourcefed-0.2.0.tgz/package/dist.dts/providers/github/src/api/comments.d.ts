export declare function fetchGithubComments(path: string): Promise<any[] | undefined>;
