import type { MonitorEvent } from "@fdcn/sourcefed/core";
export declare function parseGithubWebhook(payload: any, eventName: string, _deliveryId: string): MonitorEvent | undefined;
