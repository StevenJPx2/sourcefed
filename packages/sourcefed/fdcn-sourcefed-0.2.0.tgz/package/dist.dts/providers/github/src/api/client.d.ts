export declare function githubToken(): string | undefined;
export declare function githubJson(path: string): Promise<any | undefined>;
export declare function githubGraphQL(query: string, variables: Record<string, unknown>): Promise<any | undefined>;
