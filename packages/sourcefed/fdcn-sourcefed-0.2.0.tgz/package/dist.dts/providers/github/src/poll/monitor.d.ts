import { PollMonitor } from "@fdcn/sourcefed/core";
import type { GithubSourceRecord } from "../types";
export declare const githubPollMonitor: PollMonitor<GithubSourceRecord>;
