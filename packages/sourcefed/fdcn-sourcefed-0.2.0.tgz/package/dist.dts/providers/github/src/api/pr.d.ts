export type GithubPrData = {
    reviews: any[];
    statusCheckRollup: any[];
    mergeable?: string;
    mergeStateStatus?: string;
    state?: string;
};
export declare function fetchPrData(repo: string, prNumber: number): Promise<GithubPrData | undefined>;
