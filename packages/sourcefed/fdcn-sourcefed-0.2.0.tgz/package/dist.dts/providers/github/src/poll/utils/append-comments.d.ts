import type { GithubCursor, GithubEvent } from "../../types";
export declare function appendComments(repo: string, prNumber: number, cursor: GithubCursor, events: GithubEvent[], comments: any[], idPrefix: string, historyPrimed: boolean, summary: (comment: any) => string, body: (comment: any) => string): void;
