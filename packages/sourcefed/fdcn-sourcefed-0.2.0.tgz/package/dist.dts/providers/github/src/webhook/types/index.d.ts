export type { GithubEventHandler } from "./event-handler.js";
