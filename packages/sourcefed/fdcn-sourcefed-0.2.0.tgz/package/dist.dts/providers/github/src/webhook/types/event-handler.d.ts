import type { GithubWebhookContext } from "./context.js";
import type { GithubEventShape } from "./event-shape.js";
export type GithubEventHandler = (context: GithubWebhookContext) => GithubEventShape;
