export declare function failureRunLog(repo: string, runId: string): Promise<string | undefined>;
