import * as v from "valibot";
export declare const GithubSourceSchema: v.ObjectSchema<{
    readonly type: v.LiteralSchema<"github", undefined>;
    readonly repo: v.StringSchema<undefined>;
    readonly prNumber: v.NumberSchema<undefined>;
}, undefined>;
export declare const GithubCursorSchema: v.ObjectSchema<{
    readonly reviewIds: v.ArraySchema<v.StringSchema<undefined>, undefined>;
    readonly commentIds: v.ArraySchema<v.StringSchema<undefined>, undefined>;
    readonly historyPrimed: v.OptionalSchema<v.BooleanSchema<undefined>, false>;
    readonly lineCommentsPrimed: v.OptionalSchema<v.BooleanSchema<undefined>, false>;
    readonly conversationCommentsPrimed: v.OptionalSchema<v.BooleanSchema<undefined>, false>;
    readonly ciState: v.StringSchema<undefined>;
    readonly ciFailureState: v.OptionalSchema<v.StringSchema<undefined>, "">;
    readonly mergeable: v.StringSchema<undefined>;
    readonly prState: v.StringSchema<undefined>;
}, undefined>;
