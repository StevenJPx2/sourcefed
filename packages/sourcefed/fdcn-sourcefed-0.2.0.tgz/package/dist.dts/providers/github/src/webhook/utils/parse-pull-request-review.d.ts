import type { GithubEventShape } from "../types/event-shape.js";
import type { GithubWebhookContext } from "../types/context.js";
export declare function parsePullRequestReview({ payload, actor, repo, prNumber }: GithubWebhookContext): GithubEventShape;
