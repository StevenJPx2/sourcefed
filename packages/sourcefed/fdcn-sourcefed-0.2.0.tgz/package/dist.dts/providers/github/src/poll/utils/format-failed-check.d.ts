export declare function formatFailedCheck(check: any): string;
