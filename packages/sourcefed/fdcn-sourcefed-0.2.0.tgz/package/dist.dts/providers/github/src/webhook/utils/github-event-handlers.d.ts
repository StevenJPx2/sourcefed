import type { GithubEventHandler } from "../types";
export declare const githubEventHandlers: Record<string, GithubEventHandler>;
