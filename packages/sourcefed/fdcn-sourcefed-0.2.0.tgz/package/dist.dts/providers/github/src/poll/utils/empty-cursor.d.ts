import type { GithubCursor } from "../../types";
export declare function emptyGithubCursor(): GithubCursor;
