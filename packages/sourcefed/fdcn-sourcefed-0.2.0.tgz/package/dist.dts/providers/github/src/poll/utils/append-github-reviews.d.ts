import type { GithubCursor, GithubEvent } from "../../types";
export declare function appendGithubReviews(repo: string, prNumber: number, cursor: GithubCursor, events: GithubEvent[], reviews: any[], historyPrimed: boolean): void;
