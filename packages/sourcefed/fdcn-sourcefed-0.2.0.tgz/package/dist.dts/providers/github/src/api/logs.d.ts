export declare function fetchRunLog(repo: string, runId: string): Promise<string | undefined>;
export declare function extractZipEntries(buffer: Uint8Array): {
    name: string;
    content: Uint8Array;
}[];
