export declare function cleanCiLog(raw: string): string;
