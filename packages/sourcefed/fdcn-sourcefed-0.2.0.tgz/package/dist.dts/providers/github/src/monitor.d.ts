import { Monitor } from "@fdcn/sourcefed/core";
import type { MonitorCreateInput } from "@fdcn/sourcefed/core";
import type { GithubSourceRecord } from "./types";
import type { SourceInput } from "@fdcn/sourcefed/core";
export declare class GithubMonitor extends Monitor<GithubSourceRecord> {
    readonly poll: import("@fdcn/sourcefed/core").PollMonitor<GithubSourceRecord>;
    readonly webhook: import("@fdcn/sourcefed/core").WebhookMonitor<GithubSourceRecord>;
    constructor();
    readonly key: (source: GithubSourceRecord) => string;
    readonly icon = "\uDB80\uDEA4";
    readonly label: (source: GithubSourceRecord) => string;
    readonly detail: (source: GithubSourceRecord) => string;
    readonly describe: (source: GithubSourceRecord) => string;
    build(input: MonitorCreateInput): SourceInput;
}
