export declare function failureRunIds(failed: any[]): Set<string>;
