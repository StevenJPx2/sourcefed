import type { GithubEventShape } from "../types/event-shape.js";
import type { GithubWebhookContext } from "../types/context.js";
export declare function fallbackGithubEvent({ payload, actor, repo, prNumber, eventName }: GithubWebhookContext): GithubEventShape;
