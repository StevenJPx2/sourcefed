export declare function verifyHmac(body: string, signature: string | null, secret: string | undefined): boolean;
