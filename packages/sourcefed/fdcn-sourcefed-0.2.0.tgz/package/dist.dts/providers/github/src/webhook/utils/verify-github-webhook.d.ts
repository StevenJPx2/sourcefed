export declare function verifyGithubWebhook(body: string, request: Request): boolean;
