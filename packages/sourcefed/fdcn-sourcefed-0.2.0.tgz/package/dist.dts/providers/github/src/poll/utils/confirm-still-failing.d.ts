export declare function confirmStillFailing(repo: string, prNumber: number, failed: any[]): Promise<any[]>;
