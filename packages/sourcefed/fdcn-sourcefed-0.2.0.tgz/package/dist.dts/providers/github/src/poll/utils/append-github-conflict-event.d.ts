import type { GithubCursor, GithubEvent } from "../../types";
export declare function appendGithubConflictEvent(repo: string, prNumber: number, cursor: GithubCursor, events: GithubEvent[], mergeable: string): void;
