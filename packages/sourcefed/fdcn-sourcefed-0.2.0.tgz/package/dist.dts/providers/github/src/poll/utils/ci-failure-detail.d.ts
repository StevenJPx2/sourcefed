export declare function ciFailureDetail(repo: string, failed: any[]): Promise<string>;
