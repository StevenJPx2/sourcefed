import type { SlackCursor, SlackEvent, SlackSourceRecord } from "../../types";
export declare function pollSlack(source: SlackSourceRecord, cursorRaw: unknown): Promise<{
    events: SlackEvent[];
    cursor: SlackCursor;
    terminal: false;
}>;
