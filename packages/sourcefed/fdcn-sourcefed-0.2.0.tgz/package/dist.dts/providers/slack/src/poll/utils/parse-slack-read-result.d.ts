import type { SlackCursor, SlackEvent, SlackReadResult } from "../../types";
export declare function parseSlackReadResult(result: SlackReadResult, cursorRaw: unknown): {
    events: SlackEvent[];
    cursor: SlackCursor;
};
