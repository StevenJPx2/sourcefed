import { Monitor } from "@fdcn/sourcefed/core";
import type { MonitorCreateInput } from "@fdcn/sourcefed/core";
import type { SlackSourceRecord } from "./types";
import type { SourceInput } from "@fdcn/sourcefed/core";
export declare class SlackMonitor extends Monitor<SlackSourceRecord> {
    readonly poll: import("@fdcn/sourcefed/core").PollMonitor<SlackSourceRecord>;
    readonly webhook: import("@fdcn/sourcefed/core").WebhookMonitor<SlackSourceRecord>;
    constructor();
    readonly key: (source: SlackSourceRecord) => string;
    readonly icon = "\uDB81\uDCB1";
    readonly label: () => string;
    readonly detail: (source: SlackSourceRecord) => string;
    readonly describe: (source: SlackSourceRecord) => string;
    build(input: MonitorCreateInput): SourceInput;
}
