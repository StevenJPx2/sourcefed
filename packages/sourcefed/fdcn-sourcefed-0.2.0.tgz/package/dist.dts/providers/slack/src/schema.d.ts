import * as v from "valibot";
export declare const SlackSourceSchema: v.ObjectSchema<{
    readonly type: v.LiteralSchema<"slack", undefined>;
    readonly channelId: v.StringSchema<undefined>;
    readonly threadTs: v.StringSchema<undefined>;
}, undefined>;
export declare const SlackCursorSchema: v.ObjectSchema<{
    readonly primed: v.BooleanSchema<undefined>;
    readonly messageIds: v.ArraySchema<v.StringSchema<undefined>, undefined>;
    readonly latestTs: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
}, undefined>;
