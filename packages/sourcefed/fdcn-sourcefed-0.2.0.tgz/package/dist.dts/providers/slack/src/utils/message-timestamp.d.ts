export declare function messageTimestamp(ts: string | undefined): number;
