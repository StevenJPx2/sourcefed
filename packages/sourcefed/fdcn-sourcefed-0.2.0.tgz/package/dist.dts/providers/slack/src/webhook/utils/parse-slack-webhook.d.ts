import type { MonitorEvent } from "@fdcn/sourcefed/core";
export declare function parseSlackWebhook(payload: any, _eventName: string, deliveryId: string): MonitorEvent | undefined;
