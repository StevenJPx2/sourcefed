export declare function slackSignature(body: string, timestamp: string, secret: string): string;
