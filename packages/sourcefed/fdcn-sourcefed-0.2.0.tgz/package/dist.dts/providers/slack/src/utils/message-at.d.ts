export declare function messageAt(ts: string | undefined): string;
