export declare function fetchSlackThread(channelId: string, threadTs: string): Promise<{
    messages: any[];
    users: any[];
} | undefined>;
