import { PollMonitor } from "@fdcn/sourcefed/core";
import type { SlackSourceRecord } from "../types";
export declare const slackPollMonitor: PollMonitor<SlackSourceRecord>;
