export declare function validSlackSignature(body: string, request: Request, secret?: string | undefined): boolean;
