import { WebhookMonitor } from "@fdcn/sourcefed/core";
import type { SlackSourceRecord } from "../types";
export declare const slackWebhookMonitor: WebhookMonitor<SlackSourceRecord>;
