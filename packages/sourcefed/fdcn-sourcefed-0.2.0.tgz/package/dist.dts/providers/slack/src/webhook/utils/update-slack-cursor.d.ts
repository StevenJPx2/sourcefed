import type { MonitorEvent } from "@fdcn/sourcefed/core";
import type { SlackCursor } from "../../types";
export declare function updateSlackCursor(event: MonitorEvent, cursorRaw: unknown): SlackCursor;
