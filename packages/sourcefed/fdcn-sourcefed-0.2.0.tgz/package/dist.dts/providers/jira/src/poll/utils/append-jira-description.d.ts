import type { JiraCursor, JiraEvent } from "../../types";
export declare function appendJiraDescription(issueKey: string, cursor: JiraCursor, events: JiraEvent[], description: any): void;
