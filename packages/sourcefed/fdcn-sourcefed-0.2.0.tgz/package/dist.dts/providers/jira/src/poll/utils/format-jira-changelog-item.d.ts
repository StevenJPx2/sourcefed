export declare function formatJiraChangelogItem(item: any): string;
