export declare function adfText(node: any): string;
