export declare function meaningfulChangelogItems(items: any[]): any[];
