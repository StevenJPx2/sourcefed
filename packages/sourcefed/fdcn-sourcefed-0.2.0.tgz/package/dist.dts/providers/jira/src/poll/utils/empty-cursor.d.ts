import type { JiraCursor } from "../../types";
export declare function emptyJiraCursor(): JiraCursor;
