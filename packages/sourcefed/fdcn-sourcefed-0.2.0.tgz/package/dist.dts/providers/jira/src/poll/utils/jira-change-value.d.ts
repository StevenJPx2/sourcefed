export declare function jiraChangeValue(item: any, side: "from" | "to"): string;
