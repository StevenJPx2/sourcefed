import { Monitor } from "@fdcn/sourcefed/core";
import type { MonitorCreateInput } from "@fdcn/sourcefed/core";
import type { JiraSourceRecord } from "./types";
import type { SourceInput } from "@fdcn/sourcefed/core";
export declare class JiraMonitor extends Monitor<JiraSourceRecord> {
    readonly poll: import("@fdcn/sourcefed/core").PollMonitor<JiraSourceRecord>;
    constructor();
    readonly key: (source: JiraSourceRecord) => string;
    readonly icon = "\uDB80\uDF03";
    readonly label: (source: JiraSourceRecord) => string;
    readonly detail: (source: JiraSourceRecord) => string;
    readonly describe: (source: JiraSourceRecord) => string;
    build(input: MonitorCreateInput): SourceInput;
}
