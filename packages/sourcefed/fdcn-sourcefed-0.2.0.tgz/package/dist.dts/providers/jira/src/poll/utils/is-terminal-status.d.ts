export declare function isTerminalStatus(status: unknown): boolean;
