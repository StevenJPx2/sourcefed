export declare function jiraFetch(path: string): Promise<any>;
