import * as v from "valibot";
export declare const JiraSourceSchema: v.ObjectSchema<{
    readonly type: v.LiteralSchema<"jira", undefined>;
    readonly issueKey: v.StringSchema<undefined>;
}, undefined>;
export declare const JiraCursorSchema: v.ObjectSchema<{
    readonly commentIds: v.ArraySchema<v.NumberSchema<undefined>, undefined>;
    readonly descriptionVersion: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
    readonly changelogCount: v.NumberSchema<undefined>;
}, undefined>;
