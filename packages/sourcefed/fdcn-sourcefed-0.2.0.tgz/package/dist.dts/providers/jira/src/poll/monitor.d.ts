import { PollMonitor } from "@fdcn/sourcefed/core";
import type { JiraSourceRecord } from "../types";
export declare const jiraPollMonitor: PollMonitor<JiraSourceRecord>;
