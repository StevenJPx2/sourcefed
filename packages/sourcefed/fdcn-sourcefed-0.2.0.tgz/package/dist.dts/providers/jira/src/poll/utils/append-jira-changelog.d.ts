import type { JiraCursor, JiraEvent } from "../../types";
export declare function appendJiraChangelog(issueKey: string, cursor: JiraCursor, events: JiraEvent[], histories: any[]): void;
