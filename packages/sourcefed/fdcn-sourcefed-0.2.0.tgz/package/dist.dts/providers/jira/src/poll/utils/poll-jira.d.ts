import type { JiraCursor, JiraEvent } from "../../types";
export declare function pollJira(issueKey: string, cursorRaw: unknown): Promise<{
    events: JiraEvent[];
    cursor: JiraCursor;
    terminal: boolean;
}>;
