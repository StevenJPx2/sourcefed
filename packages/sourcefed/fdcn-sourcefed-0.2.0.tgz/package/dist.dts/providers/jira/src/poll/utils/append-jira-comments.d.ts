import type { JiraCursor, JiraEvent } from "../../types";
export declare function appendJiraComments(issueKey: string, cursor: JiraCursor, events: JiraEvent[], comments: any[]): void;
