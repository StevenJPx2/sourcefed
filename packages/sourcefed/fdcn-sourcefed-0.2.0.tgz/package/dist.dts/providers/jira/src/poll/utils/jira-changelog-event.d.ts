import type { JiraEvent } from "../../types";
export declare function jiraChangelogEvent(issueKey: string, history: any): JiraEvent | undefined;
