export declare function jiraAuth(): string;
