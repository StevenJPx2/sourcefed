export declare function callMonitorTool(name: string, arguments_: Record<string, unknown>, sessionID: string): Promise<string>;
