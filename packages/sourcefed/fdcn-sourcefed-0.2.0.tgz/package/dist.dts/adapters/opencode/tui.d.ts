import type { TuiPlugin } from "@opencode-ai/plugin/tui";
export declare const id = "sourcefed-tui";
declare const _default: {
    id: string;
    tui: TuiPlugin;
};
export default _default;
