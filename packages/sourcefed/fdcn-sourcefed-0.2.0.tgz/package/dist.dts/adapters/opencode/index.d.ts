import type { Plugin } from "@opencode-ai/plugin";
export declare const Sourcefed: Plugin;
export default Sourcefed;
