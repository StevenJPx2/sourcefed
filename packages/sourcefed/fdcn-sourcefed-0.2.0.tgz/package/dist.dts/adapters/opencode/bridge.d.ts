import type { createOpencodeClient } from "@opencode-ai/sdk";
type OpenCodeClient = ReturnType<typeof createOpencodeClient>;
export declare class OpenCodeBridge {
    private readonly opencode;
    private daemon?;
    private readonly listeners;
    private lastAttemptAt;
    private lastError;
    constructor(opencode: OpenCodeClient);
    start(): Promise<void>;
    ensureTarget(sessionID: string): Promise<void>;
    callTool(name: string, arguments_: Record<string, unknown>, sessionID: string): Promise<unknown>;
    close(): Promise<void>;
    private ensureDaemon;
    private routeEvents;
    private target;
}
export declare function setOpenCodeBridge(bridge: OpenCodeBridge): void;
export declare function getOpenCodeBridge(): OpenCodeBridge;
export {};
