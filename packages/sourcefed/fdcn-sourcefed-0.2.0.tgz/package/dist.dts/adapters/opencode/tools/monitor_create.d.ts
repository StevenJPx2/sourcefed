import { type ToolDefinition } from "@opencode-ai/plugin";
declare const definition: ToolDefinition;
export default definition;
