/** @jsxImportSource @opentui/solid */
import { type MonitorView } from "@fdcn/sourcefed/daemon";
import type { TuiPluginApi, TuiThemeCurrent } from "@opencode-ai/plugin/tui";
export type SidebarProps = {
    api: TuiPluginApi;
    sessionID: string;
};
export declare function Sidebar(props: SidebarProps): import("solid-js").JSX.Element;
export declare function MonitorRows(props: {
    monitors: () => MonitorView[];
    theme: TuiThemeCurrent;
    compact?: boolean;
}): import("solid-js").JSX.Element;
