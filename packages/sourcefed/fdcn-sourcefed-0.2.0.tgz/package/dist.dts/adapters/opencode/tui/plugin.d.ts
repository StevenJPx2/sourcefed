/** @jsxImportSource @opentui/solid */
import type { TuiPlugin } from "@opencode-ai/plugin/tui";
export declare const sourcefedTui: TuiPlugin;
