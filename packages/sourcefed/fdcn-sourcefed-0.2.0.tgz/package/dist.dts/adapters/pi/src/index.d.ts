import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
export default function sourcefedExtension(pi: ExtensionAPI): Promise<void>;
