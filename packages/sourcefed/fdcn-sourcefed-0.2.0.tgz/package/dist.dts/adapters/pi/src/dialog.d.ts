import type { Theme } from "@earendil-works/pi-coding-agent";
import type { Component, TUI } from "@earendil-works/pi-tui";
import type { LogEntryView, MonitorView } from "@fdcn/sourcefed/daemon";
type Line = {
    text: string;
};
export declare function showSourcefedDialog(_tui: TUI, theme: Theme, done: (result: null) => void, title: string, lines: Line[]): Component & {
    handleInput(data: string): void;
};
export declare function monitorLines(monitors: MonitorView[], theme: Theme): Line[];
export declare function logLines(logs: LogEntryView[], theme: Theme): Line[];
export {};
