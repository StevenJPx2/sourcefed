export type SkillInfo = {
    name: string;
    description: string;
    dir: string;
    hidden: boolean;
};
export declare function discoverSkills(): Promise<SkillInfo[]>;
