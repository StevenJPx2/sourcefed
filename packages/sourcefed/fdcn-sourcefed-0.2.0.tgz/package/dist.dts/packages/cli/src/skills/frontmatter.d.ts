export declare function parseFrontmatter(content: string): {
    name: string;
    description: string;
    hidden: boolean;
} | undefined;
