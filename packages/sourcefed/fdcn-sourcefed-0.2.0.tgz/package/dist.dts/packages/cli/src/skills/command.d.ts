export declare function runSkillsCommand(args: string[]): Promise<void>;
