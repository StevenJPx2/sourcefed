import type { Hooks } from "@opencode-ai/plugin";
import Sourcefed from "../../../adapters/opencode/index.js";
declare const _default: {
    id: string;
    server: (input: Parameters<typeof Sourcefed>[0]) => Promise<Hooks>;
};
export default _default;
