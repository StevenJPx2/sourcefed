export declare function daemonEnvironment(host?: string): Record<string, string>;
