import type { SourcefedDaemon } from "./daemon.js";
export type DaemonHttpOptions = {
    token?: string;
};
export declare function handleDaemonHttpRequest(daemon: SourcefedDaemon, request: Request, options?: DaemonHttpOptions): Promise<Response>;
