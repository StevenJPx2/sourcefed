export declare class RequestRouter {
    private readonly pending;
    private cursor;
    nextID(): number;
    register(id: number): Promise<unknown>;
    settle(id: number, frame: {
        result?: unknown;
        error?: string;
    }): void;
    rejectAll(error: Error): void;
}
