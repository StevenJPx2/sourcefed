import type { MonitorTarget } from "@fdcn/sourcefed/core";
export declare function encodeTarget(target: MonitorTarget): string;
export declare function decodeTarget(value: string): MonitorTarget | undefined;
export declare function targetKey(target: MonitorTarget): string;
