import type { MonitorEventQueue, MonitorEventSink, MonitorRecord, MonitorTarget } from "@fdcn/sourcefed/core";
export declare class NotifyingEventSink implements MonitorEventSink {
    private readonly queue;
    private readonly notify;
    constructor(queue: MonitorEventQueue, notify: (target: MonitorTarget) => void);
    deliver(input: {
        monitor: MonitorRecord;
        event: import("@fdcn/sourcefed/core").MonitorEvent;
    }): Promise<{
        ok: boolean;
        error?: string;
    }>;
}
