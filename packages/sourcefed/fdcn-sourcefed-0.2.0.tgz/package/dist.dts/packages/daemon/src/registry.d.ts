import type { Monitor, MonitorCreateInput, MonitorSource, SourceInput } from "@fdcn/sourcefed/core";
import { GithubMonitor } from "@fdcn/sourcefed/provider-github";
import { JiraMonitor } from "@fdcn/sourcefed/provider-jira";
import { SlackMonitor } from "@fdcn/sourcefed/provider-slack";
export declare const SOURCE_MAP: {
    jira: JiraMonitor;
    github: GithubMonitor;
    slack: SlackMonitor;
};
export declare const SOURCE_TYPES: [string, ...string[]];
export declare function sourceDefinition(source: MonitorSource): Monitor<any>;
export declare function isSource(input: SourceInput): input is MonitorSource;
export declare function sourceForInput(type: MonitorSource["type"], input: MonitorCreateInput): SourceInput;
export declare function sourceForWebhookPath(pathname: string): Monitor<any> | undefined;
