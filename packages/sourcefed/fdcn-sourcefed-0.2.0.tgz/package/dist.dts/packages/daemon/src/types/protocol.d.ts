import type { MonitorTarget, QueuedMonitorEvent } from "@fdcn/sourcefed/core";
export type DaemonRequest = {
    id?: number;
    method: string;
    params?: Record<string, unknown>;
};
export type DaemonResponse = {
    id?: number;
    result?: unknown;
    error?: string;
};
export type DaemonEventFrame = {
    type: "event";
    target: MonitorTarget;
    events: QueuedMonitorEvent[];
};
export type DaemonFrame = DaemonResponse | DaemonEventFrame | {
    type: "subscribed";
    target: MonitorTarget;
};
export declare function parseDaemonFrame(line: string): DaemonFrame | undefined;
