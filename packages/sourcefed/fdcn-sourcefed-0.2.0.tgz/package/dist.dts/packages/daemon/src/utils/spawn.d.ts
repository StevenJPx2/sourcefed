import { type ChildProcess } from "node:child_process";
export declare const DEFAULT_DAEMON_URL = "http://127.0.0.1:18787";
export declare function defaultDaemonUrl(): string;
export declare function daemonCommand(cliEntryPath: string): {
    command: string;
    args: string[];
};
export declare function spawnLocalDaemon(options: {
    command: string;
    args: string[];
    env?: Record<string, string>;
    port?: number;
    timeoutMs?: number;
}): Promise<{
    url: string;
    proc?: ChildProcess;
}>;
export declare function sleep(ms: number): Promise<void>;
export declare function withTimeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T>;
