import type { SourcefedDaemon } from "./daemon.js";
export declare function dispatchDaemonRequest(daemon: SourcefedDaemon, method: string, params: Record<string, unknown>): Promise<unknown>;
