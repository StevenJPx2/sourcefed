export type HttpServerOptions = {
    hostname: string;
    port: number;
    handler: (request: Request) => Promise<Response> | Response;
};
export type HttpServer = {
    port: number;
    stop(): Promise<void>;
};
export declare function serveHttp(options: HttpServerOptions): Promise<HttpServer>;
