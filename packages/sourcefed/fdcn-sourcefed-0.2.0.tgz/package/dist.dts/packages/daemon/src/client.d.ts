import type { DaemonClient, DaemonClientOptions } from "./types";
export declare function connectDaemonClient(options: DaemonClientOptions): Promise<DaemonClient>;
