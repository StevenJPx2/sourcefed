import type { MonitorTarget } from "@fdcn/sourcefed/core";
export declare function eventResourceUri(target: MonitorTarget): string;
export { decodeTarget, encodeTarget } from "@fdcn/sourcefed/daemon";
