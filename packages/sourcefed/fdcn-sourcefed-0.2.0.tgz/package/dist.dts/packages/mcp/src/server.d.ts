import { createMcpHandler, McpServer } from "@modelcontextprotocol/server";
import type { SourcefedDaemon } from "@fdcn/sourcefed/daemon";
export type SourcefedMcp = {
    runtime: SourcefedDaemon["runtime"];
    handler: ReturnType<typeof createMcpHandler>;
    close(): void;
};
export type SourcefedStdio = {
    runtime: SourcefedDaemon["runtime"];
    factory: () => McpServer;
    close(): void;
};
export declare function createSourcefedMcp(daemon: SourcefedDaemon): SourcefedMcp;
export declare function createSourcefedStdio(daemon: SourcefedDaemon): SourcefedStdio;
