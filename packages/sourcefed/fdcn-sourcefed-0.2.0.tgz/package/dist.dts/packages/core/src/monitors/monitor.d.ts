import type { MonitorContext, MonitorEvent, MonitorOptions } from "#sourcefed/types";
import type { MonitorSource, SourceInput } from "#sourcefed/sources";
import type { Delivery, MonitorCreateInput } from "#sourcefed/types";
import type { MonitorRecord } from "./types";
import type { PollMonitor } from "./poll";
import type { WebhookMonitor } from "./webhook";
export declare abstract class Monitor<TSource extends MonitorSource = MonitorSource> {
    readonly type: TSource["type"];
    private readonly schema;
    abstract readonly key: (source: TSource) => string;
    abstract build(input: MonitorCreateInput): SourceInput;
    /** Provider-specific display surface (nerd font icon, labels, describe). */
    abstract readonly icon: string;
    abstract readonly label: (source: TSource) => string;
    abstract readonly detail: (source: TSource) => string;
    abstract readonly describe: (source: TSource) => string;
    readonly poll?: PollMonitor<TSource>;
    readonly webhook?: WebhookMonitor<TSource>;
    protected constructor(options: MonitorOptions<TSource>);
    validateSource(source: unknown): TSource;
    initialDelivery(source: unknown): Delivery;
    resolveDelivery(monitor: MonitorRecord): Delivery | undefined;
    tick(context: MonitorContext, record: MonitorRecord): Promise<number>;
    deliver(context: MonitorContext, record: MonitorRecord, event: MonitorEvent, deliveryId: string): Promise<number>;
    unresponsive(record: MonitorRecord, now?: number): boolean;
}
