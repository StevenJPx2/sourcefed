import type { MonitorSource } from "./monitor-source.js";
export type SourceInput = MonitorSource | {
    error: string;
};
