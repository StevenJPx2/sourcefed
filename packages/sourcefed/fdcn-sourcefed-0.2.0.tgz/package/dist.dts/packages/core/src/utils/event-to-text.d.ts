import type { MonitorEvent } from "#sourcefed/types";
export declare function eventToText(event: MonitorEvent): string;
