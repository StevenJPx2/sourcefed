import type { MonitorSource } from "#sourcefed/sources";
import type { PollRunner } from "./poll-runner.js";
export type PollMonitorOptions<TSource extends MonitorSource> = {
    run: PollRunner<TSource>;
    mergeCursor?: (current: unknown, result: unknown) => unknown;
};
