import type { MonitorContext, MonitorEventSink, MonitorStore } from "./types";
import type { MonitorSourceRegistry } from "./sources";
import { MonitorService } from "./monitors/service.js";
import type { Monitor } from "./monitors";
export type MonitorRuntimeOptions = {
    store: MonitorStore;
    sink: MonitorEventSink;
    sources: MonitorSourceRegistry;
    sourceForWebhookPath: (path: string) => Monitor | undefined;
    pollLoopSec?: number;
};
export declare class MonitorRuntime {
    readonly service: MonitorService;
    readonly context: MonitorContext;
    private timer?;
    private readonly activeTicks;
    constructor(options: MonitorRuntimeOptions);
    private readonly pollLoopSec;
    start(): Promise<void>;
    tick(): Promise<void>;
    webhook(request: Request): Promise<Response>;
    stop(): Promise<boolean>;
}
