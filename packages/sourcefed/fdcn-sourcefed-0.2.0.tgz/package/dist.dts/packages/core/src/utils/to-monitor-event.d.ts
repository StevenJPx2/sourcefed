import type { MonitorEvent, SourceEvent } from "#sourcefed/types";
import type { MonitorSource } from "#sourcefed/sources";
export declare function toMonitorEvent(event: SourceEvent, source: MonitorSource): MonitorEvent;
