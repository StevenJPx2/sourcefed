import type { MonitorContext, MonitorEvent } from "#sourcefed/types";
import type { Monitor } from "../../monitor";
export declare function deliverWebhook(context: MonitorContext, source: Monitor, event: MonitorEvent, deliveryId: string): Promise<number>;
