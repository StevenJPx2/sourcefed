import type { MonitorRecord } from "./monitors";
import type { MonitorEvent, MonitorEventQueue, MonitorEventSink, MonitorTarget, QueuedMonitorEvent } from "./types";
export declare class QueueMonitorEventSink implements MonitorEventSink {
    readonly queue: MonitorEventQueue;
    constructor(queue: MonitorEventQueue);
    deliver(input: {
        monitor: MonitorRecord;
        event: MonitorEvent;
    }): Promise<{
        ok: boolean;
        error?: string;
    }>;
}
export declare class InMemoryMonitorEventQueue implements MonitorEventQueue {
    private readonly events;
    enqueue(input: {
        monitor: MonitorRecord;
        event: MonitorEvent;
    }): Promise<QueuedMonitorEvent>;
    read(target: MonitorTarget): Promise<QueuedMonitorEvent[]>;
    acknowledge(target: MonitorTarget, eventIDs: string[]): Promise<void>;
}
export declare function createQueuedMonitorEvent(monitor: MonitorRecord, event: MonitorEvent): QueuedMonitorEvent;
export declare function monitorEventID(event: MonitorEvent): string;
