import type { MonitorSource } from "#sourcefed/sources";
import type { MonitorTarget } from "#sourcefed/types";
import type { MonitorRecord } from "../types";
export declare function monitorIdentity(target: MonitorTarget, source: MonitorSource): string;
export declare function dedupeActiveMonitors(monitors: MonitorRecord[]): MonitorRecord[];
