import type * as v from "valibot";
import type { MonitorRecordSchema } from "../schema.js";
export type MonitorRecord = v.InferOutput<typeof MonitorRecordSchema>;
