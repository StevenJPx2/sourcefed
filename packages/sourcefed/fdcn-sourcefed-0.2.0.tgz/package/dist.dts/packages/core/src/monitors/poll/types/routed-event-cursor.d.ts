import * as v from "valibot";
export declare const RoutedEventCursorSchema: v.ArraySchema<v.StringSchema<undefined>, undefined>;
