export declare const WEBHOOK_STALE_MS = 90000;
export declare const WEBHOOK_STARTUP_GRACE_MS = 120000;
