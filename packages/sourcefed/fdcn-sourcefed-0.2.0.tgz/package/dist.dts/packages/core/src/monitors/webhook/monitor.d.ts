import type { MonitorContext, MonitorEvent } from "#sourcefed/types";
import type { MonitorSource } from "#sourcefed/sources";
import type { MonitorRecord } from "../types";
import type { Monitor } from "../monitor";
import { type WebhookMonitorOptions } from "./types";
export declare class WebhookMonitor<TSource extends MonitorSource = MonitorSource> {
    readonly path: string;
    readonly preferred: boolean;
    readonly configured: () => boolean;
    readonly verify: (body: string, request: Request) => boolean;
    readonly acknowledgeBeforeDelivery: boolean;
    readonly challenge?: (payload: unknown) => Record<string, string> | undefined;
    readonly deliveryId: (request: Request, payload: unknown) => string | undefined;
    readonly eventName: (request: Request, payload: unknown) => string;
    readonly parse: (payload: unknown, eventName: string, deliveryId: string) => MonitorEvent | undefined;
    readonly updateCursor?: (event: MonitorEvent, cursor: unknown) => unknown;
    constructor(options: WebhookMonitorOptions);
    isHealthy(record: MonitorRecord): boolean;
    isUnresponsive(record: MonitorRecord, now: number): boolean;
    retryPending(context: MonitorContext, source: Monitor<TSource>, record: MonitorRecord): Promise<number>;
    private addPending;
    private removePending;
    deliver(context: MonitorContext, source: Monitor<TSource>, record: MonitorRecord, event: MonitorEvent, deliveryId: string): Promise<number>;
}
