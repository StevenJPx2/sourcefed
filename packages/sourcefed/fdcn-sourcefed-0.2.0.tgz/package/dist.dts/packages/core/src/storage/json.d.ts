import type { MonitorRecord, MonitorRegistry } from "../monitors/types";
import type { MonitorEvent, MonitorEventQueue, MonitorStore, MonitorTarget, QueuedMonitorEvent } from "../types";
export type JsonMonitorStoreOptions = {
    stateDir?: string;
};
export declare class JsonMonitorStore implements MonitorStore {
    readonly stateDir: string;
    readonly stateFile: string;
    constructor(options?: JsonMonitorStoreOptions);
    load(): Promise<MonitorRegistry>;
    acquireExclusive(): Promise<() => Promise<void>>;
    save(registry: MonitorRegistry): Promise<void>;
    private readRaw;
}
export declare function defaultJsonMonitorStore(options?: JsonMonitorStoreOptions): JsonMonitorStore;
export declare class JsonMonitorEventQueue implements MonitorEventQueue {
    readonly stateDir: string;
    readonly eventsFile: string;
    private queue;
    constructor(stateDir: string);
    enqueue(input: {
        monitor: MonitorRecord;
        event: MonitorEvent;
    }): Promise<QueuedMonitorEvent>;
    read(target: MonitorTarget): Promise<QueuedMonitorEvent[]>;
    acknowledge(target: MonitorTarget, eventIDs: string[]): Promise<void>;
    private transact;
    private loadEvents;
    private saveEvents;
}
