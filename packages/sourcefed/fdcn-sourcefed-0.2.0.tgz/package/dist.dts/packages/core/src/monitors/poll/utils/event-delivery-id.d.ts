import type { MonitorEvent } from "#sourcefed/types";
export declare function eventDeliveryId(event: MonitorEvent): string;
