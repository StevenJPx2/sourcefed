import type { MonitorContext } from "#sourcefed/types";
import type { Monitor } from "../../monitor";
export declare function heartbeatWebhooks(context: MonitorContext, source: Monitor, eventSource: unknown): Promise<void>;
