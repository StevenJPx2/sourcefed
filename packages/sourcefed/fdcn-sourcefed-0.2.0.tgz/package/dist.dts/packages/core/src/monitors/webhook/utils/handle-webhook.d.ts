import type { MonitorContext } from "#sourcefed/types";
export declare function handleWebhook(request: Request, context: MonitorContext): Promise<Response>;
