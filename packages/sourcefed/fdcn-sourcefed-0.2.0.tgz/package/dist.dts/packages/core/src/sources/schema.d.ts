import * as v from "valibot";
export declare const MonitorSourceSchema: v.IntersectSchema<[v.ObjectSchema<{
    readonly type: v.StringSchema<undefined>;
}, undefined>, v.RecordSchema<v.StringSchema<undefined>, v.UnknownSchema, undefined>], undefined>;
