import type { MonitorSource } from "#sourcefed/sources";
import type { MonitorStore, MonitorTarget } from "#sourcefed/types";
import type { MonitorRecord } from "./types";
export type CreateMonitorInput = {
    name: string;
    source: MonitorSource;
    delivery: "poll" | "webhook";
    target: MonitorTarget;
    pollIntervalSec: number;
};
export type CreateMonitorResult = {
    monitor: MonitorRecord;
    created: boolean;
};
export declare class MonitorService {
    readonly store: MonitorStore;
    private registryQueue;
    constructor(store: MonitorStore);
    list(): Promise<MonitorRecord[]>;
    get(id: string): Promise<MonitorRecord | undefined>;
    create(input: CreateMonitorInput): Promise<CreateMonitorResult>;
    stop(id: string): Promise<MonitorRecord | {
        error: string;
    }>;
    start(id: string): Promise<MonitorRecord | {
        error: string;
    }>;
    remove(id: string): Promise<void>;
    setDelivery(id: string, delivery: "poll" | "webhook"): Promise<void>;
    updateCursor(monitor: MonitorRecord, key: string, value: unknown): Promise<void>;
    updateCursorValue(monitor: MonitorRecord, key: string, update: (cursor: unknown) => unknown): Promise<void>;
    dedupe(): Promise<number>;
    private updateMonitor;
    private transact;
}
