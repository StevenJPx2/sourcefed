import type { MonitorSource } from "#sourcefed/sources";
import type { MonitorContext } from "#sourcefed/types";
import type { MonitorRecord } from "../types";
import type { Monitor } from "../monitor";
import { type PollMonitorOptions } from "./types";
export declare class PollMonitor<TSource extends MonitorSource = MonitorSource> {
    private readonly options;
    constructor(options: PollMonitorOptions<TSource>);
    run(context: MonitorContext, source: Monitor<TSource>, record: MonitorRecord): Promise<number>;
    isUnresponsive(record: MonitorRecord, now: number): boolean;
}
export declare function mergeCursors(current: unknown, result: unknown): unknown;
