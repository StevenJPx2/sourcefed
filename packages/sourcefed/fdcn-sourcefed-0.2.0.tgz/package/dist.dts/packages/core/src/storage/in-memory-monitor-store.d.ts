import type { MonitorStore } from "../types/monitor-store.js";
import type { MonitorRegistry } from "../monitors/types/monitor-registry.js";
export declare class InMemoryMonitorStore implements MonitorStore {
    private registry;
    constructor(initial?: MonitorRegistry);
    load(): Promise<MonitorRegistry>;
    save(registry: MonitorRegistry): Promise<void>;
}
