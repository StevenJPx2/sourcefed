import type { MonitorEvent } from "./monitor-event.js";
import type { MonitorRecord } from "../monitors/types/monitor-record.js";
export type EventDeliveryResult = {
    ok: boolean;
    error?: string;
};
export interface MonitorEventSink {
    deliver(input: {
        monitor: MonitorRecord;
        event: MonitorEvent;
    }): Promise<EventDeliveryResult>;
}
