import type { MonitorEvent } from "./monitor-event.js";
export type SourcePollResult = {
    cursor: unknown;
    events: MonitorEvent[];
    terminal: boolean;
};
