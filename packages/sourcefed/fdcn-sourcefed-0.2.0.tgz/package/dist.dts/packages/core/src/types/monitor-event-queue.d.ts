import type { MonitorEvent } from "./monitor-event.js";
import type { MonitorTarget } from "./monitor-target.js";
import type { MonitorRecord } from "../monitors/types/monitor-record.js";
export type QueuedMonitorEvent = {
    id: string;
    monitorID: string;
    target: MonitorTarget;
    event: MonitorEvent;
    queuedAt: string;
};
export interface MonitorEventQueue {
    enqueue(input: {
        monitor: MonitorRecord;
        event: MonitorEvent;
    }): Promise<QueuedMonitorEvent>;
    read(target: MonitorTarget): Promise<QueuedMonitorEvent[]>;
    acknowledge(target: MonitorTarget, eventIDs: string[]): Promise<void>;
}
