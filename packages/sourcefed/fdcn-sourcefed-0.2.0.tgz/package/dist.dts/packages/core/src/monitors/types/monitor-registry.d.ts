import type * as v from "valibot";
import type { MonitorRegistrySchema } from "../schema.js";
export type MonitorRegistry = v.InferOutput<typeof MonitorRegistrySchema>;
