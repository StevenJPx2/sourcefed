import * as v from "valibot";
export declare const MonitorRecordSchema: v.ObjectSchema<{
    readonly id: v.StringSchema<undefined>;
    readonly name: v.StringSchema<undefined>;
    readonly source: v.IntersectSchema<[v.ObjectSchema<{
        readonly type: v.StringSchema<undefined>;
    }, undefined>, v.RecordSchema<v.StringSchema<undefined>, v.UnknownSchema, undefined>], undefined>;
    readonly delivery: v.PicklistSchema<["poll", "webhook"], undefined>;
    readonly target: v.ObjectSchema<{
        readonly kind: v.StringSchema<undefined>;
        readonly id: v.StringSchema<undefined>;
    }, undefined>;
    readonly pollIntervalSec: v.NumberSchema<undefined>;
    readonly enabled: v.BooleanSchema<undefined>;
    readonly createdAt: v.StringSchema<undefined>;
    readonly updatedAt: v.StringSchema<undefined>;
    readonly cursors: v.RecordSchema<v.StringSchema<undefined>, v.UnknownSchema, undefined>;
}, undefined>;
export declare const MonitorRegistrySchema: v.ObjectSchema<{
    readonly monitors: v.ArraySchema<v.ObjectSchema<{
        readonly id: v.StringSchema<undefined>;
        readonly name: v.StringSchema<undefined>;
        readonly source: v.IntersectSchema<[v.ObjectSchema<{
            readonly type: v.StringSchema<undefined>;
        }, undefined>, v.RecordSchema<v.StringSchema<undefined>, v.UnknownSchema, undefined>], undefined>;
        readonly delivery: v.PicklistSchema<["poll", "webhook"], undefined>;
        readonly target: v.ObjectSchema<{
            readonly kind: v.StringSchema<undefined>;
            readonly id: v.StringSchema<undefined>;
        }, undefined>;
        readonly pollIntervalSec: v.NumberSchema<undefined>;
        readonly enabled: v.BooleanSchema<undefined>;
        readonly createdAt: v.StringSchema<undefined>;
        readonly updatedAt: v.StringSchema<undefined>;
        readonly cursors: v.RecordSchema<v.StringSchema<undefined>, v.UnknownSchema, undefined>;
    }, undefined>, undefined>;
}, undefined>;
