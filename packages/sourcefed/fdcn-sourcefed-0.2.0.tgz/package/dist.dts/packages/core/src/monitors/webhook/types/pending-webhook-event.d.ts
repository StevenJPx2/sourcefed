import * as v from "valibot";
import type { MonitorEvent } from "#sourcefed/types";
export type PendingWebhookEvent = {
    deliveryId: string;
    event: MonitorEvent;
};
export declare const PendingWebhookEventsSchema: v.ArraySchema<v.ObjectSchema<{
    readonly deliveryId: v.StringSchema<undefined>;
    readonly event: v.ObjectSchema<{
        readonly source: v.UnknownSchema;
        readonly kind: v.StringSchema<undefined>;
        readonly id: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
        readonly at: v.StringSchema<undefined>;
        readonly summary: v.StringSchema<undefined>;
        readonly body: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
        readonly actionable: v.BooleanSchema<undefined>;
        readonly terminal: v.OptionalSchema<v.BooleanSchema<undefined>, undefined>;
    }, undefined>;
}, undefined>, undefined>;
