import type { MonitorContext } from "#sourcefed/types";
export declare function tick(context: MonitorContext): Promise<void>;
