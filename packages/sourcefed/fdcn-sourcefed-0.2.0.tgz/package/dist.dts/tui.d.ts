export { default } from "./adapters/opencode/tui.js";
